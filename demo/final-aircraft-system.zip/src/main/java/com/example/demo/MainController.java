package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import java.util.stream.Collectors;

@Controller
public class MainController {

    @Autowired
    private AircraftRepository aircraftRepository;

    @Autowired
    private MaintenanceRecordRepository maintenanceRecordRepository;

    @Autowired
    private SparePartRepository sparePartRepository;

    @GetMapping("/")
    public String defaultRootPage() { return "login"; }

    @GetMapping("/login")
    public String viewLoginPage() { return "login"; }

    @GetMapping("/dashboard")
    public String viewDashboardPage(Model model) {
        model.addAttribute("aircraftList", aircraftRepository.findAll());
        return "dashboard";
    }

    @GetMapping("/aircrafts")
    public String viewAircraftInventoryPage(Model model) {
        model.addAttribute("aircraftList", aircraftRepository.findAll());
        model.addAttribute("newAircraft", new Aircraft());
        return "aircrafts"; 
    }

    @PostMapping("/aircrafts/add")
    public String addNewAircraftToFleet(@ModelAttribute Aircraft aircraft) {
        aircraftRepository.save(aircraft);
        return "redirect:/aircrafts";
    }

    @GetMapping("/maintenance")
    public String viewMaintenanceRecordsPage(Model model) {
        model.addAttribute("recordsList", maintenanceRecordRepository.findAll());
        model.addAttribute("aircraftList", aircraftRepository.findAll());
        return "records"; 
    }

    // 4. Inventory Page Router Node Layer
    @GetMapping("/inventory")
    public String viewInventoryPage(Model model) {
        var allParts = sparePartRepository.findAll();
        
        // Filter out items that are running low to populate Phase 8 real-time critical warnings alerts row
        var lowStockAlerts = allParts.stream()
            .filter(part -> part.getCurrentStock() <= part.getMinimumStock())
            .collect(Collectors.toList());

        model.addAttribute("partsList", allParts);
        model.addAttribute("lowStockAlerts", lowStockAlerts);
        model.addAttribute("newPart", new SparePart());
        return "inventory";
    }

    // 5. Handles inventory component logging additions
    @PostMapping("/inventory/add")
    public String addNewPartToStock(@ModelAttribute SparePart part) {
        sparePartRepository.save(part);
        return "redirect:/inventory";
    }
}
